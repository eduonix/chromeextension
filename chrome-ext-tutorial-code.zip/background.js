chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.msg === 'show-popup') {
        chrome.pageAction.show(sender.tab.id);
    }
});